package com.pencilstub.pieces3d.pieces3dedit;

import com.alibaba.fastjson.JSON;
import com.google.gson.JsonObject;
import com.jayfella.jme.jfx.JavaFxUI;
import com.jayfella.jme.jfx.util.AnimUtils;
import com.jayfella.jme.jfx.util.NodeFactory;
import com.jme3.anim.AnimClip;
import com.jme3.anim.AnimComposer;
import com.jme3.anim.SkinningControl;
import com.jme3.app.ChaseCameraAppState;
import com.jme3.app.SimpleApplication;
import com.jme3.bounding.BoundingBox;
import com.jme3.export.binary.BinaryExporter;
import com.jme3.light.LightProbe;
import com.jme3.math.FastMath;
import com.jme3.math.Matrix3f;
import com.jme3.math.Quaternion;
import com.jme3.math.Vector3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.Node;
import com.jme3.scene.Spatial;
import com.jme3.system.JmeSystem;
import com.pencilstub.pieces3d.pieces3dedit.state.AxisAppState;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import jme3utilities.MySpatial;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class AnimReuser extends SimpleApplication {

    private LightProbe probeNode;
    private AnimClip animClipSource;

    private Spatial spatialSource, spatialTarget;

    private Geometry selectBox, selectBox1;

    public static void main(String... args) {
        AnimReuser main = new AnimReuser();
        main.start();
    }

    public AnimReuser() {
        super(new AxisAppState());
    }

    @Override
    public void simpleUpdate(float tpf) {
        inputManager.setCursorVisible(true);
    }

    @Override
    public void simpleInitApp() {
        Node node = new Node();
        node.move(new Vector3f(0f, 2f, 0f));
        ChaseCameraAppState chaseCameraAppState = new ChaseCameraAppState();
        chaseCameraAppState.setTarget(node);
        getStateManager().attach(chaseCameraAppState);

        JavaFxUI.initialize(this);
        FXMLLoader fxmlLoader = new FXMLLoader(AnimReuser.class.getResource("hello-view.fxml"));
        VBox vBox = null;
        try {
            vBox = fxmlLoader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }

        Button button = new Button("Click Me");
        JavaFxUI.getInstance().attachChild(vBox);

        selectBox = NodeFactory.makeSelectBox(assetManager);
        selectBox1 = NodeFactory.makeSelectBox(assetManager);
        rootNode.attachChild(selectBox);
        rootNode.attachChild(selectBox1);

        probeNode = (LightProbe) assetManager.loadAsset("sky/clearSky_probe.j3o");
        rootNode.addLight(probeNode);

        spatialSource = assetManager.loadModel("Models/huoying/untitled.gltf");
        spatialSource.setName("source");
        rootNode.attachChild(spatialSource);
        Vector3f scaleS = setHeight(spatialSource);


        spatialTarget = assetManager.loadModel("Models/kakaxi/3/untitled.gltf");
        spatialTarget.setName("target");
        Vector3f scaleT = setHeight(spatialTarget);
        spatialTarget.setLocalTranslation(2f, 0f, 0f);
        rootNode.attachChild(spatialTarget);

//        try {
//            saveJ3oModel(spatialSource, JmeSystem.getStorageFolder() + File.separator + "source.j3o");
//            saveJ3oModel(spatialTarget, JmeSystem.getStorageFolder() + File.separator + "target.j3o");
//        } catch (IOException e) {
//            e.printStackTrace();
//        }


        AnimComposer animComposerSource = AnimUtils.findAnimComposer(spatialSource);
        SkinningControl skinningControlSource = AnimUtils.findSkinningControl(spatialSource);
        animClipSource = (AnimClip) assetManager.loadAsset("Models/huoying/大步走.j3o");
//        animComposerSource.setCurrentAction(animClipSource.getName());
//        if (animComposerSource != null) {
//            for (AnimClip animClip : animComposerSource.getAnimClips()) {
////                System.out.println(" animClip name:" + animClip.getName());
//                if ("大步走".equals(animClip.getName())) {
//                    System.out.println(" clip name:" + animClip.getName());
//                    animClipSource = animClip;
//                }
//
//                try {
//                    saveAnim(animClip, JmeSystem.getStorageFolder() + File.separator + animClip.getName()+".j3o");
//                } catch (IOException e) {
//                    e.printStackTrace();
//                }
//            }
//
//
////            animComposerSource.setCurrentAction(animClipSource.getName());
//        }

//
//
//        SkinningControl skinningControl = AnimUtils.findSkinningControl(spatialTarget);
//
//        SkeletonMapping skeletonMapping = new SkeletonMapping();
//        List<Joint> joints = skinningControl.getArmature().getJointList();
//        for(Joint joint:joints){
////            System.out.println(" sourceJoint name:"+joint.getName()+" size:"+joints.size());
//            BoneMapping boneMapping = new BoneMapping();
//            boneMapping.setSourceName(joint.getName());
//            boneMapping.setTargetName(joint.getName());
//            boneMapping.setTwist(Quaternion.IDENTITY);
//            skeletonMapping.addMapping(boneMapping);
//        }
//
//
//        AnimClip walkAnim = AnimationEdit.retargetAnimation(animClipSource,
//                skinningControlSource.getArmature(), skinningControl.getArmature(), skeletonMapping, animClipSource.getName());
//        AnimComposer composer = AnimUtils.findAnimComposer(spatialTarget);
//        composer.addAnimClip(walkAnim);
//        composer.setCurrentAction(walkAnim.getName());

//        AnimClip animClipTarget1 = AnimUtils.retargetClip(animClipSource, spatialSource, "mixamorig:Hips",1f);
//        animComposerSource.addAnimClip(animClipTarget1);
////        spatialSource.setLocalRotation(new Quaternion().fromAngleAxis(-FastMath.HALF_PI, Vector3f.UNIT_X));
//        animComposerSource.setCurrentAction(animClipTarget1.getName());
////
////
        AnimComposer animComposer = AnimUtils.findAnimComposer(spatialTarget);
//        AnimClip animClipTarget = AnimUtils.retargetClip(animClipSource, spatialTarget, "mixamorig:Hips",4.693f);
//        animComposer.addAnimClip(animClipTarget);
//        animComposer.setCurrentAction(animClipTarget.getName());

        System.out.println("divide:" + scaleT.divide(scaleS));
    }

    private Vector3f setHeight(Spatial spatial) {
//        BoundingBox bbox = (BoundingBox) spatial.getWorldBound();
//        Vector3f vector3f = bbox.getExtent(null);
//        System.out.println(" yyyyy:" + vector3f + " name:" + spatial.getName());
//        //统一高度为3f
        SkinningControl sc = AnimUtils.findSkinningControl(spatial);
        if (spatial.getUserData("hasInitialPose") == null) {
            System.out.println("hasInitialPose is null!");
//            sc.getArmature().applyBindPose();
            sc.getArmature().applyInitialPose();
//            sc.getArmature().saveBindPose();
            sc.getArmature().saveInitialPose();
            spatial.setUserData("hasInitialPose", Boolean.TRUE);
        }

        Vector3f[] minMax = MySpatial.findMinMaxCoords(spatial);
        System.out.println("name:"+spatial.getName()+" minMax:"+ JSON.toJSONString(minMax));
        float oldHeight = minMax[1].z - minMax[0].z;
        float scale = 3f/oldHeight;
//        spatial.scale(scale);
//        float scale = 2f / vector3f.y;
        spatial.scale(scale);
//        //获取实际的对角线长度
//        float widthX = FastMath.sqrt(vector3f.x * vector3f.x + vector3f.z * vector3f.z);
        System.out.println("oldheight:"+oldHeight+"scale:" + scale + " wolrdscale:" + spatial.getWorldScale() );
        return spatial.getWorldScale();
    }

    private void saveAnim(AnimClip s, String path) throws IOException {
        System.out.println("path:" + path);
        File file = new File(path);
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        BinaryExporter exp = BinaryExporter.getInstance();
        exp.save(s, fileOutputStream);
    }

    private void saveJ3oModel(Spatial s, String path) throws IOException {
        System.out.println("path:" + path);
        File file = new File(path);
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        BinaryExporter exp = BinaryExporter.getInstance();
        exp.save(s, fileOutputStream);
    }

    boolean flag = true;

    @Override
    public void update() {
        super.update();
        BoundingBox bbox = (BoundingBox) spatialSource.getWorldBound();
        selectBox.setLocalScale(bbox.getExtent(null));
        selectBox.setLocalTranslation(bbox.getCenter());

//        Quaternion quaternion = new Quaternion();
//        quaternion.fromAngleAxis(-FastMath.HALF_PI, new Vector3f(0,1,0));
//        selectBox.setLocalRotation(quaternion);

        BoundingBox bbox1 = (BoundingBox) spatialTarget.getWorldBound();
        selectBox1.setLocalScale(bbox1.getExtent(null));
        selectBox1.setLocalTranslation(bbox1.getCenter());
        if (flag) {
            System.out.println(" bbox:" + bbox.getExtent(null) + "   bbox1:" + bbox1.getExtent(null));
            flag = false;
        }
    }
}